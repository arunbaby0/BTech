//Multiprogramming 
//Either of the thread runs first 
//Using Runnable interface
import java.io.*;
	class newth1 implements Runnable
	{
		Thread t;
		newth1()
		{
			 t=new Thread(this,"First child thread");
			 t.start();
		}
	public void run()
	{
		try{
			for(int i=0;i<5;i++)
			{
			   System.out.println("hello");
				// System.out.println("hello"+t);	
			   t.sleep(1000);
			}
		}catch(Exception e){}
	}
	}
class thr3
{
 public static void main(String g[])
 {
new newth1();
   try
    {
     System.out.println("main my thread");
    }catch(Exception e){}
 
 }
}
