import java.io.*;

class thr 
 {
public static void main(String s[])
{
String a[]={"m","y","n","a","m","e","i","s",""};
Thread t=Thread.currentThread();
try
{
for(int i=0;i<11;i++)
{ 
System.out.println(a[i]);
Thread.sleep(1000);
}}catch(Exception e){}
}}
