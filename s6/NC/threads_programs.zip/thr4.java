//Multiprogramming 
//Using Extends Thread 
import java.io.*;
	class newth1 extends Thread
	{
	newth1()
		{
		start();
		}
	public void run()
	{
		try{
			for(int i=0;i<5;i++)
			{
			   System.out.println("hello");
				// System.out.println("hello"+t);	
			  Thread.sleep(1000);
			}
		}catch(Exception e){}
	}
	}
class thr4
{
 public static void main(String g[])
 {
new newth1();
   try
    {
     System.out.println("main my thread");
    }catch(Exception e){}
 
 }
}
