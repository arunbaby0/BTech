import java.io.*;

class thr2 
 {
public static void main(String s[])
{

Thread t=Thread.currentThread();
t.setName("HELLO");
try
{
for(int i=0;i<10;i++)
{ 
System.out.println(i);
Thread.sleep(1000);
}}catch(Exception e){}
System.out.println(t);
}}
