#include <math.h>
#include <stdio.h>
#include <dos.h>
#include <math.h>
#include <conio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <graphics.h>
#include <values.h>

union   REGS i, o;

typedef struct {int x; int y;} wcPt2;
#define NControls 8
#define NPoints   640
int     c[NControls];
wcPt2 Controlpnts[NControls+4];
wcPt2 Curve[NPoints];

int    GraphDriver;		/* The Graphics device driver		*/
int    GraphMode;		/* The Graphics mode value		*/
int    MaxX, MaxY;		/* The maximum resolution of the screen */
int    MaxColors;		/* The maximum # of colors available	*/
int    ErrorCode;		/* Reports any graphics errors		*/

int initmouse(void)
{
  i.x.ax = 0;
  int86(0x33,&i,&o);
  return (o.x.ax);
}

void showmouseptr(void)
{
	i.x.ax = 1;
	int86(0x33, &i, &o);
}

void getmousepos(int *button, int *x, int *y)
{
  i.x.ax = 3;
  int86(0x33, &i, &o);
  *button = o.x.bx;
  *x = o.x.cx;
  *y = o.x.dx;
}

void Initialize(void)
{
  GraphDriver = DETECT; 		/* Request auto-detection	*/
  initgraph( &GraphDriver, &GraphMode, "" );
  ErrorCode = graphresult();		/* Read result of initialization*/
  if( ErrorCode != grOk ){		/* Error occured during init	*/
    printf(" Graphics System Error: %s\n", grapherrormsg( ErrorCode ) );
    exit( 1 );
  }
  MaxColors = getmaxcolor() + 1;	/* Read maximum number of colors*/
  MaxX = getmaxx();                     /* Read size of screen          */
  MaxY = getmaxy();			/* Read size of screen		*/
}

void computeCoefficients (int n)
{
  int k,i;
  for (k=0; k<=n; k++) {     /* Compute n!/(k!(n-k)!) */
	  c[k] = 1;
	  for(i=n; i>=k+1; i--) c[k] *= i;
	  for(i=n-k; i>=2; i--) c[k] /= i;
  }
}

void computePoint(float u, wcPt2 *pt, wcPt2 *controls,int nControls)
{
  int n,k;
  double a1,b1,a2,b2;
  float blend,ptx,pty;

  n = nControls-1;
  ptx = pty = 0.0;

  /* Add in influence of each control point */

  for(k=0; k<=nControls; k++) {
      a1 = (double)u; b1 = (double)k; a2 = (double)(1.0-u); b2 = (double)(n-k);
      blend = c[k] * pow(a1,b1)* pow(a2,b2);
      ptx += (float)controls[k].x * blend;
      pty += (float)controls[k].y * blend;
  }
  pt->x = (int)(ptx+0.5);
  pt->y = (int)pty;
}

void bezier(wcPt2 *controls, int m, wcPt2 *curve, int nControls)
{
 /* Allocate Space for the coefficients */
	int i;
	computeCoefficients (nControls-1);
	for (i=0; i<=m; i++)
	  computePoint(i/(float)(m), &curve[i], controls,nControls);
}

main(int argc, char *argv[])
{
 int n,nPoints,nControls;
 int xpos, ypos, button, color;
 int xmin, xmax;

 nControls = 4;
 if (argc > 1) {
      nControls = atoi(argv[1]);
      if( nControls > NControls) nControls = NControls;
 }
 Initialize(); 		        /* Set system into Graphics mode	*/

 if (initmouse() == 0 ) printf("\nMouse driver not loaded");
 showmouseptr();

 printf("Select %d Control points\n",nControls);
 n=0;
 color = 1;
 setfillstyle(SOLID_FILL,color);
 setcolor(WHITE);
 while (n < nControls) {
     getmousepos(&button, &xpos, &ypos);
     if(button==1)  {
       Controlpnts[n].x = xpos;
       Controlpnts[n].y = ypos;
       sleep(1);
       circle(xpos,ypos,6);
       n++;
     }
 }
 setcolor(4);
 moveto(Controlpnts[0].x,Controlpnts[0].y);
 xmin = xmax = Controlpnts[0].x;
 for(n=0; n<nControls; n++) {
    lineto(Controlpnts[n].x,Controlpnts[n].y);
    if(xmin > Controlpnts[n].x) xmin = Controlpnts[n].x;
    if(xmax < Controlpnts[n].x) xmax = Controlpnts[n].x;
 }
 nPoints = xmax - xmin +1;
 setcolor(15);
 bezier(&Controlpnts[0], nPoints, &Curve[0], nControls);

/*
 Controlpnts[0].x = 100;
 Controlpnts[0].y = 50;
 Controlpnts[1].x = 250;
 Controlpnts[1].y = 400;
 Controlpnts[2].x = 550;
 Controlpnts[2].y = 400;
 Controlpnts[3].x = 500;
 Controlpnts[3].y = 50;

*/

 moveto(Curve[1].x,Curve[1].y);
 for(n=1; n< nPoints;n++) lineto(Curve[n].x,Curve[n].y);

 getch();
 closegraph(); 		        /* Return the system to text mode	*/
 return 0;
}
