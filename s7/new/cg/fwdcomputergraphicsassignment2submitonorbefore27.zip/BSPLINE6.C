/* Computer Graphics assignment - 2   CS7 - ALPHA
 *
 * Generate and plot a Bspline curves defined by Cox-deBoor recursion formulae.
 * Use Constant spacing between Knot values so that Uniform B-Spline curve
 * is generated,
 * Plot the following 3 curves (In 3 different colors)
 *  1. Linear -  d=2 ( Degree 1 )
 *  2. Quadratic d=3 ( Degree 2 )
 *  3. Cubic     d=4 ( Degree 3 )
 *
 * The Graphics screen may be initialized to a size of 640 x 480 pixels.
 * The Control points (5 control points) are generated from your Role number.
 * Change the defined constant RoleNo to your role number. Change MyName to
 * your name.
 *
 * Submission materials:
 * 1. Print out of the program (developed from this template).
 * 2. Screen dump of the Graphics output showing the BSpline curves along
 *    with the 5 controlpoints. Control points are already plotted by this
 *    program).
 * Note: You may use Borland TurboC (Freely downloadable) for the purpose
 *       of coding the Bspline functions and generating the plot of the
 *       Bspline curve.
 *       Keep EGAVGA.BGI in the directory where you keep the executable.
 *       This is to ensure that the screen gets initialized with 640x480.
 *
 *       Submission deadline:  27-Sep-2010 (EOD)
*/

#include <math.h>
#include <stdio.h>
#include <dos.h>
#include <math.h>
#include <conio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <graphics.h>
#include <values.h>

#define RoleNo 30
#define NControls 5
char *MyName = "Janardhanan";

typedef struct {int x; int y;} wcPt2;
wcPt2 Controlpnts[4];
wcPt2 Curve[NControls];

int    GraphDriver;		/* The Graphics device driver		*/
int    GraphMode;		/* The Graphics mode value		*/
int    MaxX, MaxY;		/* The maximum resolution of the screen */
int    MaxColors;		/* The maximum # of colors available	*/
int    ErrorCode;		/* Reports any graphics errors		*/

void Initialize(void)
{
  GraphDriver = DETECT; 		/* Request auto-detection	*/
  initgraph( &GraphDriver, &GraphMode, "" );
  ErrorCode = graphresult();		/* Read result of initialization*/
  if( ErrorCode != grOk ){		/* Error occured during init	*/
    printf(" Graphics System Error: %s\n", grapherrormsg( ErrorCode ) );
    exit( 1 );
  }
  MaxColors = getmaxcolor() + 1;	/* Read maximum number of colors*/
  MaxX = getmaxx();                     /* Read size of screen          */
  MaxY = getmaxy();			/* Read size of screen		*/
}

main()
{
 int n,nPoints,nControls;
 int xmin, xmax,ix,iy;
 int Xstp;

 Initialize(); 		        /* Set system into Graphics mode	*/

/* Do not modify code from here onwards*/
 setcolor(15);
 for(iy=0;iy<MaxY;iy++) {
   moveto(0,iy);
   lineto(MaxX-1,iy);
 }
 printf("\Role No=%d Name=%s", RoleNo,MyName);
 Xstp = MaxX/10;
 Controlpnts[0].x = Xstp;
 Controlpnts[0].y = RoleNo+40;
 Controlpnts[1].x = Xstp*3;
 Controlpnts[1].y = RoleNo*6+40;
 Controlpnts[2].x = Xstp*5;
 Controlpnts[2].y = RoleNo+40;
 Controlpnts[3].x = Xstp*7;
 Controlpnts[3].y = RoleNo*6+40;
 Controlpnts[4].x = Xstp*9;
 Controlpnts[4].y = RoleNo+40;
 for(n=0; n<NControls; n++) {
   setcolor(3);
   circle(Controlpnts[n].x,Controlpnts[n].y,6);
   setcolor(0);
   circle(Controlpnts[n].x,Controlpnts[n].y,3);
 }
 /* Add your code below this. */

 getch();
 closegraph(); 		        /* Return the system to text mode	*/
 return 0;
}
